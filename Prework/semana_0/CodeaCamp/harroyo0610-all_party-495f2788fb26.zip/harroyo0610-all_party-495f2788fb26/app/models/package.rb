class Package < ApplicationRecord
end
