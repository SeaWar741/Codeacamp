require 'test_helper'

class ReservationProductTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
