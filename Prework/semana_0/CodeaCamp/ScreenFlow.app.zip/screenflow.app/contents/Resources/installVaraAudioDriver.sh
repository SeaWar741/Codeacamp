#!/bin/sh

export KEXT=$1
installer -pkg "$KEXT" -target /