class ApplicationMailer < ActionMailer::Base
  default from: 'noreply@todoparatufiesta.mx'
  layout 'mailer'
end
