class PackagesController < ApplicationController
  def index
     
  end

  def create
    p user_package = params[:package]
  end
end
