class PartysController < ApplicationController
  def index
    
  end
end
